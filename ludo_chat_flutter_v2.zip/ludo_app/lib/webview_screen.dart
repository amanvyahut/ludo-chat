import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _setupWebView();
  }

  void _setupWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)

      // Android WebView mein localStorage & Firebase ke liye zaroori
      ..setBackgroundColor(const Color(0xFF0B0B1A))

      // Navigation delegate
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            if (mounted) setState(() { _isLoading = true; _hasError = false; });
          },
          onPageFinished: (url) {
            if (mounted) setState(() => _isLoading = false);
          },
          onWebResourceError: (error) {
            // Firebase/font errors ko ignore karo, sirf fatal errors dikhao
            if (error.errorCode == -2) {
              // NET_ERROR — internet nahi hai
              if (mounted) setState(() { _isLoading = false; _hasError = true; });
            }
          },
        ),
      )

      // Flutter se JavaScript call karne ke liye channel
      ..addJavaScriptChannel(
        'FlutterApp',
        onMessageReceived: (JavaScriptMessage message) {
          _handleJSMessage(message.message);
        },
      )

      // Local HTML file load karo assets se
      ..loadFlutterAsset('assets/www/index.html');
  }

  void _handleJSMessage(String message) {
    // Game se koi message aaye to yahan handle karo
    // Abhi ke liye sirf print kar rahe hain
    debugPrint('JS Message: $message');
  }

  // Back button handle karo — game ke andar navigation ke liye
  Future<bool> _onWillPop() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }

    // Game chhod ne ka confirmation
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF161A35),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          '🎲 Game Chhodni Hai?',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: const Text(
          'Kya aap Ludo Chat se bahar jana chahte hain?',
          style: TextStyle(color: Color(0xFF9AA0C5)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Ruko', style: TextStyle(color: Color(0xFFFFC940))),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Haan, Bahar Jao', style: TextStyle(color: Color(0xFFE6483B))),
          ),
        ],
      ),
    );

    if (shouldExit == true) {
      SystemNavigator.pop();
    }
    return false;
  }

  void _reload() {
    setState(() { _isLoading = true; _hasError = false; });
    _controller.reload();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: const Color(0xFF0B0B1A),
        body: SafeArea(
          child: Stack(
            children: [
              // Main WebView
              WebViewWidget(controller: _controller),

              // Loading indicator
              if (_isLoading)
                Container(
                  color: const Color(0xFF0B0B1A),
                  child: const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('🎲', style: TextStyle(fontSize: 60)),
                        SizedBox(height: 20),
                        CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFC940)),
                          strokeWidth: 2.5,
                        ),
                        SizedBox(height: 16),
                        Text(
                          'Game Load Ho Raha Hai...',
                          style: TextStyle(color: Color(0xFF6B7299), fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ),

              // Error screen — internet nahi hai
              if (_hasError && !_isLoading)
                Container(
                  color: const Color(0xFF0B0B1A),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('📡', style: TextStyle(fontSize: 60)),
                          const SizedBox(height: 16),
                          const Text(
                            'Internet Nahi Mila!',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Online multiplayer aur chat ke liye internet zaroori hai.\nOffline mode phir bhi kaam karega!',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Color(0xFF6B7299), fontSize: 13, height: 1.5),
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: _reload,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFFC940),
                              foregroundColor: const Color(0xFF2A1500),
                              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              'Dobara Try Karo',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
