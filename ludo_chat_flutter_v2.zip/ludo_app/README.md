# 🎲 Ludo Chat — Flutter Android App

Aapki Ludo Chat website ka Flutter Android app!

---

## 📁 Project Structure

```
ludo_app/
├── lib/
│   ├── main.dart          → App entry point + Splash screen
│   └── webview_screen.dart → Main game screen (WebView)
├── assets/
│   └── www/
│       └── index.html     → Aapka Ludo Chat game
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml → Internet permissions
└── pubspec.yaml           → Dependencies
```

---

## 🚀 Setup Kaise Kare (Step by Step)

### Step 1: Flutter Install Karo
```
https://flutter.dev/docs/get-started/install/windows
```

### Step 2: Android Studio Install Karo
- Android SDK chahiye
- Android Emulator ya real phone connect karo (USB Debugging on)

### Step 3: Project Setup
```bash
# Project folder mein jao
cd ludo_app

# Dependencies install karo
flutter pub get
```

### Step 4: App Chalao
```bash
# Connected device check karo
flutter devices

# App run karo
flutter run
```

### Step 5: Release APK Banao (Play Store ke liye)
```bash
flutter build apk --release
```
APK milegi: `build/app/outputs/flutter-apk/app-release.apk`

---

## ✅ Features

- 🎮 **Ludo Board** — Canvas par drawn, smoothly kaam karta hai
- 🔥 **Firebase** — Online multiplayer + Real-time chat
- 🌐 **Offline Mode** — Internet ke bina bhi khel sakte hain
- 🔊 **Sound Effects** — Web Audio API se synthesized
- 📱 **Full Screen** — Immersive game experience
- ↩️ **Back Button** — Game chhodne ka confirmation
- 📡 **No Internet Screen** — User-friendly error message

---

## ⚠️ Important Notes

1. **Firebase kaam karega?** — Haan! HTML file mein pehle se Firebase config hai, internet se connect hogi
2. **Fonts load honge?** — Haan, Google Fonts CDN se load honge (internet chahiye)
3. **Minimum Android version** — Android 5.0+ (API 21+)

---

## 🔧 Troubleshooting

**Error: Gradle build failed**
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter run
```

**Error: SDK not found**
- Android Studio → SDK Manager mein Android SDK install karo

---

## 📞 Help Chahiye?

Claude.ai par jao aur project file paste karo!
